import { test, expect } from '@playwright/test'

test('iszukajka', async ({ page }) => {
  await page.goto('https://www.pepper.pl/')
  await page.getByRole('button', { name: 'Akceptuj wszystkie' }).click()
  await page.getByRole('textbox', { name: 'Szukaj...' }).click()
  await page.getByRole('textbox', { name: 'Szukaj...' }).fill('iphone')
  await page.getByRole('textbox', { name: 'Szukaj...' }).press('Enter')
  await page.getByRole('listitem').filter({ hasText: 'Ukryj zakończone' }).locator('span').nth(1).click()
  await page.locator('span').filter({ hasText: 'Największa trafność Najnowsze' }).getByRole('combobox').selectOption('lowest_price')
  // od tego miejsca można zacząć test:)
  await page.goto('https://www.pepper.pl/search?q=iphone&hide_expired=true&sortBy=lowest_price')
  await page.screenshot({ path: './screenshots/screenshot.png', fullPage: true })
})