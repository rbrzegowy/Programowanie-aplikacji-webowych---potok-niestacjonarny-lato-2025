import { test, expect } from '@playwright/test'
import { assert } from 'console'

test('test', async ({ page }) => {
  await page.goto('https://www.pepper.pl/')
  await page.getByRole('button', { name: 'Akceptuj wszystkie' }).click()
  await page.getByPlaceholder('Szukaj...').click()
  await page.getByPlaceholder('Szukaj...').fill('iphone')
  await page.getByPlaceholder('Szukaj...').press('Enter')
  await page.locator('label').filter({ hasText: 'Ukryj stacjonarne' }).locator('span').nth(1).click()
  await page.locator('label').filter({ hasText: '200° i więcej' }).locator('div').click()
  const iloscProduktow = (await page.locator('.js-trhreadList').all()).length

  // debugowanie 
  // w vscode - debugger, breakpoints
  // w debuggerze playwright:
  await page.pause()

  await expect(page.getByText('493°')).toBeVisible()
  await expect(page.locator('#thread_838135')).toContainText('493')

  const najnizszaCena = await expect(page.locator('#thread_838135')).toContainText('1 599zł')


  await page.screenshot({ path: './screenshot.png', fullPage: true })
  // albo do bufora i do bazy albo np. na maila
  // const buffer = await page.screenshot()
  // console.log(buffer.toString('base64'))
})